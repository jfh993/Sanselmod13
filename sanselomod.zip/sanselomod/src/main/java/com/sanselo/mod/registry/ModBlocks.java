package com.sanselo.mod.registry;

import com.sanselo.mod.SanseloMod;
import net.minecraft.util.valueproviders.UniformInt;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import com.sanselo.mod.block.MeteoriteOreBlock;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModBlocks {
    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, SanseloMod.MODID);

    public static final RegistryObject<Block> METEORITE_ORE = BLOCKS.register("meteorite_ore",
            () -> new MeteoriteOreBlock(BlockBehaviour.Properties.copy(Blocks.DIAMOND_ORE)
                    .strength(4.5f, 4f).lightLevel(s -> 5), UniformInt.of(3, 6)));
}
