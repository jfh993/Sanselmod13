package com.sanselo.mod.registry;

import com.sanselo.mod.SanseloMod;
import com.sanselo.mod.entity.BossEntity;
import com.sanselo.mod.entity.SilentCloneEntity;
import com.sanselo.mod.entity.StoryNpcEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, SanseloMod.MODID);

    public static final RegistryObject<EntityType<SilentCloneEntity>> CLONE = ENTITIES.register("silent_clone",
            () -> EntityType.Builder.of(SilentCloneEntity::new, MobCategory.MONSTER)
                    .sized(0.6f, 1.95f).clientTrackingRange(8).build("silent_clone"));

    public static final RegistryObject<EntityType<StoryNpcEntity>> NPC = ENTITIES.register("story_npc",
            () -> EntityType.Builder.of(StoryNpcEntity::new, MobCategory.MISC)
                    .sized(0.6f, 1.8f).clientTrackingRange(10).build("story_npc"));

    public static final RegistryObject<EntityType<BossEntity>> BOSS = ENTITIES.register("echo_boss",
            () -> EntityType.Builder.of(BossEntity::new, MobCategory.MONSTER)
                    .sized(0.8f, 2.6f).fireImmune().clientTrackingRange(10).build("echo_boss"));
}
