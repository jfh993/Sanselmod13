package com.sanselo.mod.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.sanselo.mod.entity.BossEntity;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.resources.ResourceLocation;

public class BossRenderer extends HumanoidMobRenderer<BossEntity, StoryModel<BossEntity>> {
    private static final ResourceLocation[] TEX = {
            new ResourceLocation("sanselomod", "textures/entity/jdh.png"),
            new ResourceLocation("sanselomod", "textures/entity/sanselo.png"),
            new ResourceLocation("sanselomod", "textures/entity/echo_boss.png")
    };

    public BossRenderer(EntityRendererProvider.Context ctx) {
        super(ctx, new StoryModel<>(ctx.bakeLayer(ModelLayers.PLAYER)), 0.7f);
    }

    @Override
    protected void scale(BossEntity e, PoseStack ps, float partial) {
        float s = 1.2f + 0.03f * (float) Math.sin((e.tickCount + partial) / 6.0);
        ps.scale(s, s, s);
    }

    @Override
    public ResourceLocation getTextureLocation(BossEntity e) {
        return TEX[Math.max(0, Math.min(2, e.variantId()))];
    }
}
