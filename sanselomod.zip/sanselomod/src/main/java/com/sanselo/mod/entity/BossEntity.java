package com.sanselo.mod.entity;

import com.sanselo.mod.fx.Fx;
import com.sanselo.mod.registry.ModEntities;
import com.sanselo.mod.story.StoryManager;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.BossEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

/** Финальный противник. Три фазы: клоны -> осколочные волны -> ярость. */
public class BossEntity extends Monster implements Animated {
    private final ServerBossEvent bossEvent =
            new ServerBossEvent(getDisplayName(), BossEvent.BossBarColor.PURPLE, BossEvent.BossBarOverlay.PROGRESS);
    private int phase = 1;
    private static final EntityDataAccessor<Integer> VARIANT = SynchedEntityData.defineId(BossEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> PHASE_SYNC = SynchedEntityData.defineId(BossEntity.class, EntityDataSerializers.INT);

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        entityData.define(VARIANT, 2);
        entityData.define(PHASE_SYNC, 1);
    }

    public void setVariant(int v) { entityData.set(VARIANT, v); }
    @Override public int variantId() { return entityData.get(VARIANT); }
    @Override public int phaseId() { return entityData.get(PHASE_SYNC); }


    private static final String[] JDH_LINES = {"Ты серьёзно этим машешь? Ладно, продолжай.", "Не перебивай, я заканчиваю мысль!",
            "Гениально! Нет, подожди, это я про себя.", "Давай, давай, у меня таймер.", "Четвёртая стена, подвинься, у нас тут драма."};
    private static final String[] SANS_LINES = {"Ты так и не вспомнил.", "Хозяин? Нет. Черновик.", "Осколок помнит больше, чем ты.", "Зачем ты пришёл?"};
    private static final String[] VEA_LINES = {"Каждая Искра будет моей.", "Ты слишком медленный.", "Отдай то, что тебе не принадлежит."};

    public BossEntity(EntityType<? extends Monster> type, Level level) {
        super(type, level);
        this.xpReward = 100;
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 300.0)
                .add(Attributes.MOVEMENT_SPEED, 0.30)
                .add(Attributes.ATTACK_DAMAGE, 8.0)
                .add(Attributes.ARMOR, 6.0)
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.6)
                .add(Attributes.FOLLOW_RANGE, 40.0);
    }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.0, false));
        goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.8));
        goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 16.0f));
        goalSelector.addGoal(7, new RandomLookAroundGoal(this));
        targetSelector.addGoal(1, new HurtByTargetGoal(this));
        targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }

    @Override
    protected void customServerAiStep() {
        super.customServerAiStep();
        bossEvent.setProgress(getHealth() / getMaxHealth());
        if (!(level() instanceof ServerLevel sl)) return;
        if (tickCount == 1) {
            Fx.lightning(sl, getX(), getY(), getZ());
            Fx.ring(sl, ParticleTypes.SOUL_FIRE_FLAME, getX(), getY() + 0.1, getZ(), 3, 48);
        }
        if (tickCount % 5 == 0) {
            sl.sendParticles(phase == 1 ? ParticleTypes.PORTAL : phase == 2 ? ParticleTypes.REVERSE_PORTAL : ParticleTypes.SOUL_FIRE_FLAME,
                    getX(), getY() + 1.2, getZ(), 4, 0.5, 0.9, 0.5, 0.02);
        }

        float hp = getHealth() / getMaxHealth();
        int newPhase = hp > 0.66f ? 1 : hp > 0.33f ? 2 : 3;
        if (newPhase != phase) {
            phase = newPhase;
            entityData.set(PHASE_SYNC, phase);
            String msg = phase == 2 ? "Фаза 2: осколочные волны!" : "Фаза 3: ярость!";
            for (ServerPlayer p : sl.getEntitiesOfClass(ServerPlayer.class, getBoundingBox().inflate(40))) {
                p.sendSystemMessage(Component.literal(msg));
                Fx.title(p, "Фаза " + phase, phase == 2 ? "Осколочные волны" : "Ярость");
            }
            if (phase == 3) {
                addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 1_000_000, 1, false, false));
                addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 1_000_000, 0, false, false));
            }
            sl.playSound(null, blockPosition(), SoundEvents.WITHER_SPAWN, SoundSource.HOSTILE, 0.6f, 1.4f);
            Fx.lightning(sl, getX(), getY(), getZ());
            Fx.ring(sl, ParticleTypes.REVERSE_PORTAL, getX(), getY() + 0.1, getZ(), 4, 60);
        }

        if (tickCount % 100 == 0 && phase != 2) summonClones(sl);
        if (tickCount % 60 == 0 && phase >= 2) shardWave(sl);
        if (tickCount % 300 == 150) quip(sl);
    }

    private void quip(ServerLevel sl) {
        String n = hasCustomName() ? getCustomName().getString() : "";
        String[] l = n.contains("jdh") ? JDH_LINES : n.contains("Санселло") ? SANS_LINES : n.contains("Вея") ? VEA_LINES : null;
        if (l == null) return;
        String who = n.contains(",") ? n.substring(0, n.indexOf(',')) : n;
        for (ServerPlayer p : sl.getEntitiesOfClass(ServerPlayer.class, getBoundingBox().inflate(40))) {
            p.sendSystemMessage(Component.literal("<" + who + "> " + l[random.nextInt(l.length)]).withStyle(ChatFormatting.YELLOW));
        }
    }

    private void summonClones(ServerLevel sl) {
        int near = sl.getEntitiesOfClass(SilentCloneEntity.class, getBoundingBox().inflate(24)).size();
        if (near >= 6) return;
        for (int i = 0; i < 2; i++) {
            SilentCloneEntity c = ModEntities.CLONE.get().create(sl);
            if (c == null) continue;
            c.moveTo(getX() + random.nextInt(7) - 3, getY(), getZ() + random.nextInt(7) - 3, random.nextFloat() * 360f, 0f);
            sl.addFreshEntity(c);
            sl.sendParticles(ParticleTypes.PORTAL, c.getX(), c.getY() + 1, c.getZ(), 20, 0.3, 0.8, 0.3, 0.1);
        }
    }

    private void shardWave(ServerLevel sl) {
        for (Player p : sl.getEntitiesOfClass(Player.class, getBoundingBox().inflate(10))) {
            p.hurt(damageSources().magic(), phase == 3 ? 7f : 5f);
            if (phase == 3) p.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 40, 0));
            sl.sendParticles(ParticleTypes.REVERSE_PORTAL, p.getX(), p.getY() + 1, p.getZ(), 30, 0.4, 0.8, 0.4, 0.15);
        }
        sl.playSound(null, blockPosition(), SoundEvents.AMETHYST_BLOCK_RESONATE, SoundSource.HOSTILE, 1.5f, 0.6f);
    }

    @Override
    public void die(DamageSource source) {
        super.die(source);
        if (level() instanceof ServerLevel sl) {
            sl.sendParticles(ParticleTypes.EXPLOSION_EMITTER, getX(), getY() + 1, getZ(), 1, 0, 0, 0, 0);
            sl.sendParticles(ParticleTypes.TOTEM_OF_UNDYING, getX(), getY() + 1, getZ(), 120, 1, 1.5, 1, 0.4);
            sl.playSound(null, blockPosition(), SoundEvents.AMETHYST_BLOCK_RESONATE, SoundSource.HOSTILE, 2f, 0.5f);
            for (ServerPlayer p : sl.getEntitiesOfClass(ServerPlayer.class, getBoundingBox().inflate(80))) {
                StoryManager.onBossDefeated(p);
            }
        }
    }

    @Override public boolean removeWhenFarAway(double d) { return false; }

    @Override
    public void setCustomName(Component name) {
        super.setCustomName(name);
        bossEvent.setName(getDisplayName());
    }

    @Override public void startSeenByPlayer(ServerPlayer p) { super.startSeenByPlayer(p); bossEvent.addPlayer(p); }
    @Override public void stopSeenByPlayer(ServerPlayer p) { super.stopSeenByPlayer(p); bossEvent.removePlayer(p); }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("Variant", variantId());
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.contains("Variant")) setVariant(tag.getInt("Variant"));
        if (hasCustomName()) bossEvent.setName(getDisplayName());
    }
}
