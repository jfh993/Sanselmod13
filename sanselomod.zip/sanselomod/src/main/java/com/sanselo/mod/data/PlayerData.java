package com.sanselo.mod.data;

import com.sanselo.mod.network.ModNetwork;
import net.minecraft.ChatFormatting;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.CapabilityManager;
import net.minecraftforge.common.capabilities.CapabilityToken;
import net.minecraftforge.common.util.INBTSerializable;

public class PlayerData implements INBTSerializable<CompoundTag> {
    public static final Capability<PlayerData> CAP = CapabilityManager.get(new CapabilityToken<>() {});

    public PlayerRole role = PlayerRole.NONE;
    public int composure = 100;
    public int shards, cloneKills, riftVisits, chapter, ending, ending2, spared, pages;
    public String girlName = "";
    public boolean bossDefeated;
    public long transferReadyTick, lossUntil;

    public static PlayerData get(Player p) {
        return p.getCapability(CAP).orElse(new PlayerData());
    }

    public void resetProgress() {
        composure = 100;
        shards = 0;
        cloneKills = 0;
        spared = 0;
        pages = 0;
        ending2 = 0;
        girlName = "";
        riftVisits = 0;
        chapter = 0;
        ending = 0;
        bossDefeated = false;
        transferReadyTick = 0;
        lossUntil = 0;
    }

    /** Меняет самообладание. При нуле Санселло теряет контроль. */
    public void changeComposure(ServerPlayer sp, int delta) {
        int old = composure;
        composure = Mth.clamp(composure + delta, 0, 100);
        if (composure == 0 && old > 0) {
            lossUntil = sp.level().getGameTime() + 600;
            composure = 25;
            sp.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 200, 0));
            sp.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 100, 1));
            sp.sendSystemMessage(Component.literal("Ты потерял самообладание. Клоны больше не считают тебя хозяином.")
                    .withStyle(ChatFormatting.DARK_RED, ChatFormatting.ITALIC));
        }
        ModNetwork.sync(sp);
    }

    public void copyFrom(PlayerData o) {
        role = o.role; composure = o.composure; shards = o.shards; cloneKills = o.cloneKills;
        riftVisits = o.riftVisits; spared = o.spared; pages = o.pages; ending2 = o.ending2; girlName = o.girlName; chapter = o.chapter; ending = o.ending; bossDefeated = o.bossDefeated;
        transferReadyTick = o.transferReadyTick; lossUntil = o.lossUntil;
    }

    @Override
    public CompoundTag serializeNBT() {
        CompoundTag t = new CompoundTag();
        t.putInt("role", role.ordinal());
        t.putInt("composure", composure);
        t.putInt("shards", shards);
        t.putInt("cloneKills", cloneKills);
        t.putInt("riftVisits", riftVisits);
        t.putInt("chapter", chapter);
        t.putInt("ending", ending);
        t.putInt("spared", spared);
        t.putInt("pages", pages);
        t.putInt("ending2", ending2);
        t.putString("girl", girlName);
        t.putBoolean("boss", bossDefeated);
        t.putLong("transfer", transferReadyTick);
        t.putLong("loss", lossUntil);
        return t;
    }

    @Override
    public void deserializeNBT(CompoundTag t) {
        role = PlayerRole.values()[Mth.clamp(t.getInt("role"), 0, PlayerRole.values().length - 1)];
        composure = t.getInt("composure");
        shards = t.getInt("shards");
        cloneKills = t.getInt("cloneKills");
        riftVisits = t.getInt("riftVisits");
        chapter = t.getInt("chapter");
        ending = t.getInt("ending");
        spared = t.getInt("spared");
        pages = t.getInt("pages");
        ending2 = t.getInt("ending2");
        girlName = t.getString("girl");
        bossDefeated = t.getBoolean("boss");
        transferReadyTick = t.getLong("transfer");
        lossUntil = t.getLong("loss");
    }
}
