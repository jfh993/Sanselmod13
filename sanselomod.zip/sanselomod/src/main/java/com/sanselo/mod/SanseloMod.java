package com.sanselo.mod;

import com.sanselo.mod.network.ModNetwork;
import com.sanselo.mod.registry.ModBlocks;
import com.sanselo.mod.registry.ModEntities;
import com.sanselo.mod.registry.ModItems;
import com.sanselo.mod.registry.ModTabs;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(SanseloMod.MODID)
public class SanseloMod {
    public static final String MODID = "sanselomod";

    public SanseloMod() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ModBlocks.BLOCKS.register(bus);
        ModItems.ITEMS.register(bus);
        ModEntities.ENTITIES.register(bus);
        ModTabs.TABS.register(bus);
        bus.addListener(this::commonSetup);
    }

    private void commonSetup(FMLCommonSetupEvent e) {
        e.enqueueWork(ModNetwork::register);
    }
}
