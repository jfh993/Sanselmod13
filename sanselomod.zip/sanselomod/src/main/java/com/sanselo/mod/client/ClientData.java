package com.sanselo.mod.client;

import com.sanselo.mod.data.PlayerRole;

public class ClientData {
    public static PlayerRole role = PlayerRole.NONE;
    public static int composure = 100;
    public static int chapter = 0;
    public static float shownComposure = 100f;
}
