package com.sanselo.mod.worldgen;

import com.sanselo.mod.registry.ModBlocks;
import com.sanselo.mod.registry.ModItems;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.RandomSource;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.MapItem;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LadderBlock;
import net.minecraft.world.level.block.entity.ChestBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.saveddata.SavedData;
import net.minecraft.world.level.saveddata.maps.MapDecoration;
import net.minecraft.world.level.saveddata.maps.MapItemSavedData;

/** Сюжетные локации вокруг спавна. Строятся, когда игрок подходит ближе 110 блоков. */
public final class StructureGen {
    private StructureGen() {}

    public record Site(String name, int dx, int dz, int radius) {}

    public static final Site[] SITES = {
            new Site("Кратер метеорита", 90, 60, 14),
            new Site("Башня «Не верь тому, кто помнит»", -70, 100, 8),
            new Site("Подземная лаборатория", 30, -110, 12),
            new Site("Деревня пепла", -110, -60, 20)
    };

    public static class State extends SavedData {
        public int built;

        public static State get(ServerLevel ow) {
            return ow.getDataStorage().computeIfAbsent(State::load, State::new, "sanselomod_structures");
        }

        public static State load(CompoundTag t) {
            State s = new State();
            s.built = t.getInt("built");
            return s;
        }

        @Override
        public CompoundTag save(CompoundTag t) {
            t.putInt("built", built);
            return t;
        }
    }

    public static BlockPos siteXZ(ServerLevel ow, int i) {
        BlockPos sp = ow.getSharedSpawnPos();
        return new BlockPos(sp.getX() + SITES[i].dx(), 0, sp.getZ() + SITES[i].dz());
    }

    /** Вызывается раз в пару секунд для игрока в Верхнем мире. */
    public static void tick(ServerLevel ow, ServerPlayer sp) {
        State st = State.get(ow);
        for (int i = 0; i < SITES.length; i++) {
            if ((st.built & (1 << i)) != 0) continue;
            BlockPos c = siteXZ(ow, i);
            if (Math.hypot(sp.getX() - c.getX(), sp.getZ() - c.getZ()) > 110) continue;
            int r = SITES[i].radius() + 3;
            BlockPos a = new BlockPos(c.getX() - r, ow.getMinBuildHeight(), c.getZ() - r);
            BlockPos b = new BlockPos(c.getX() + r, ow.getMinBuildHeight() + 1, c.getZ() + r);
            if (!ow.hasChunksAt(a, b)) continue;
            switch (i) {
                case 0 -> crater(ow, c);
                case 1 -> tower(ow, c);
                case 2 -> lab(ow, c);
                case 3 -> village(ow, c);
                default -> { }
            }
            st.built |= 1 << i;
            st.setDirty();
        }
    }

    // ------------------------------------------------------------ карта
    public static ItemStack makeMap(ServerLevel ow) {
        BlockPos sp = ow.getSharedSpawnPos();
        ItemStack map = MapItem.create(ow, sp.getX(), sp.getZ(), (byte) 2, true, true);
        MapItem.renderBiomePreviewMap(ow, map);
        for (int i = 0; i < SITES.length; i++) {
            MapItemSavedData.addTargetDecoration(map, siteXZ(ow, i), "site" + i,
                    i == 0 ? MapDecoration.Type.RED_X : MapDecoration.Type.TARGET_X);
        }
        map.setHoverName(Component.literal("Карта мироходца"));
        return map;
    }

    // ------------------------------------------------------------ помощники
    private static final BlockState AIR = Blocks.AIR.defaultBlockState();

    private static int ground(ServerLevel l, int x, int z) {
        return l.getHeight(Heightmap.Types.WORLD_SURFACE_WG, x, z) - 1;
    }

    private static void set(ServerLevel l, int x, int y, int z, BlockState s) {
        l.setBlock(new BlockPos(x, y, z), s, 2);
    }

    private static void chest(ServerLevel l, int x, int y, int z, ItemStack... items) {
        BlockPos p = new BlockPos(x, y, z);
        l.setBlock(p, Blocks.CHEST.defaultBlockState(), 2);
        if (l.getBlockEntity(p) instanceof ChestBlockEntity c) {
            for (int i = 0; i < items.length; i++) c.setItem(i, items[i]);
        }
    }

    // ------------------------------------------------------------ кратер метеорита
    private static void crater(ServerLevel l, BlockPos c) {
        RandomSource rnd = l.getRandom();
        int cx = c.getX(), cz = c.getZ(), g = ground(l, cx, cz), r = 11;
        BlockState ore = ModBlocks.METEORITE_ORE.get().defaultBlockState();
        for (int dx = -r - 2; dx <= r + 2; dx++) {
            for (int dz = -r - 2; dz <= r + 2; dz++) {
                double d = Math.sqrt(dx * dx + dz * dz);
                if (d > r + 2) continue;
                int x = cx + dx, z = cz + dz, gy = ground(l, x, z);
                if (d <= r) {
                    int bottom = g - (int) Math.round(5 * (1 - d / r));
                    for (int y = bottom + 1; y <= Math.max(gy, bottom) + 6; y++) set(l, x, y, z, AIR);
                    BlockState b = (d <= 5 && rnd.nextFloat() < 0.28f) || (d <= 9 && rnd.nextFloat() < 0.08f)
                            ? ore : Blocks.BLACKSTONE.defaultBlockState();
                    set(l, x, bottom, z, b);
                } else {
                    set(l, x, gy, z, rnd.nextBoolean() ? Blocks.COARSE_DIRT.defaultBlockState() : Blocks.BLACKSTONE.defaultBlockState());
                }
            }
        }
        set(l, cx, g - 5, cz, Blocks.CRYING_OBSIDIAN.defaultBlockState());
        set(l, cx, g - 4, cz, Blocks.AMETHYST_CLUSTER.defaultBlockState());
    }

    // ------------------------------------------------------------ башня
    private static void tower(ServerLevel l, BlockPos c) {
        RandomSource rnd = l.getRandom();
        int cx = c.getX(), cz = c.getZ(), g = ground(l, cx, cz);
        for (int y = 0; y <= 13; y++) {
            for (int dx = -2; dx <= 2; dx++) {
                for (int dz = -2; dz <= 2; dz++) {
                    boolean wall = Math.abs(dx) == 2 || Math.abs(dz) == 2;
                    boolean floor = y == 0 || y == 6;
                    BlockState s = null;
                    if (floor) {
                        if (y == 0 || rnd.nextFloat() < 0.6f) s = Blocks.STONE_BRICKS.defaultBlockState();
                        else s = AIR;
                    } else if (wall) {
                        if (rnd.nextFloat() > y / 16f) {
                            s = rnd.nextFloat() < 0.3f ? Blocks.MOSSY_STONE_BRICKS.defaultBlockState()
                                    : rnd.nextFloat() < 0.3f ? Blocks.CRACKED_STONE_BRICKS.defaultBlockState()
                                    : Blocks.STONE_BRICKS.defaultBlockState();
                        } else s = AIR;
                    } else s = AIR;
                    if ((y == 1 || y == 2) && dx == 0 && dz == -2) s = AIR; // вход
                    set(l, cx + dx, g + y, cz + dz, s);
                }
            }
        }
        chest(l, cx + 1, g + 1, cz + 1, new ItemStack(ModItems.SHARD.get(), 2), new ItemStack(ModItems.MEMORY_PAGE.get(), 2));
    }

    // ------------------------------------------------------------ подземная лаборатория
    private static void lab(ServerLevel l, BlockPos c) {
        int cx = c.getX(), cz = c.getZ();
        int g = ground(l, cx, cz), labY = g - 14, sx = cx, sz = cz - 8;
        BlockState brick = Blocks.STONE_BRICKS.defaultBlockState();
        // площадка и люк
        for (int dx = -2; dx <= 2; dx++) for (int dz = -2; dz <= 2; dz++) set(l, sx + dx, g, sz + dz, brick);
        // стены шахты
        for (int y = labY; y < g; y++) {
            for (int dx = -1; dx <= 1; dx++) for (int dz = -1; dz <= 1; dz++) set(l, sx + dx, y, sz + dz, brick);
        }
        // шахта с лестницей
        BlockState ladder = Blocks.LADDER.defaultBlockState().setValue(LadderBlock.FACING, Direction.SOUTH);
        for (int y = labY + 1; y < g; y++) set(l, sx, y, sz, ladder);
        set(l, sx, g, sz, Blocks.OAK_TRAPDOOR.defaultBlockState());
        // туннель к комнате
        for (int z = sz + 1; z <= cz - 4; z++) {
            for (int dx = -1; dx <= 1; dx++) for (int y = labY; y <= labY + 3; y++) set(l, sx + dx, y, z, brick);
            set(l, sx, labY + 1, z, AIR);
            set(l, sx, labY + 2, z, AIR);
        }
        set(l, sx, labY + 1, sz, AIR);
        set(l, sx, labY + 2, sz, AIR);
        // комната
        for (int dx = -6; dx <= 6; dx++) {
            for (int dz = -4; dz <= 4; dz++) {
                for (int y = labY; y <= labY + 5; y++) {
                    boolean shell = Math.abs(dx) == 6 || Math.abs(dz) == 4 || y == labY || y == labY + 5;
                    set(l, cx + dx, y, cz + dz, shell ? brick : AIR);
                }
            }
        }
        set(l, cx, labY + 1, cz - 4, AIR);
        set(l, cx, labY + 2, cz - 4, AIR);
        for (int dx : new int[]{-3, 3}) for (int dz : new int[]{-2, 2}) set(l, cx + dx, labY + 5, cz + dz, Blocks.SEA_LANTERN.defaultBlockState());
        // капсулы клонов, последняя разбита и без таблички
        for (int dx : new int[]{-4, -2, 0, 2, 4}) {
            set(l, cx + dx, labY + 2, cz + 3, Blocks.SEA_LANTERN.defaultBlockState());
            for (int y = labY + 1; y <= labY + 3; y++) {
                if (dx == 4 && y > labY + 1) continue;
                set(l, cx + dx, y, cz + 2, Blocks.GLASS.defaultBlockState());
            }
        }
        chest(l, cx - 5, labY + 1, cz - 3, new ItemStack(ModItems.SHARD.get(), 3), new ItemStack(ModItems.MEMORY_PAGE.get(), 3));
    }

    // ------------------------------------------------------------ деревня пепла
    private static void village(ServerLevel l, BlockPos c) {
        RandomSource rnd = l.getRandom();
        int cx = c.getX(), cz = c.getZ();
        for (int dx = -20; dx <= 20; dx++) {
            for (int dz = -20; dz <= 20; dz++) {
                if (dx * dx + dz * dz > 400 || rnd.nextFloat() > 0.3f) continue;
                BlockPos p = new BlockPos(cx + dx, ground(l, cx + dx, cz + dz), cz + dz);
                BlockState s = l.getBlockState(p);
                if (s.is(Blocks.GRASS_BLOCK) || s.is(Blocks.DIRT)) l.setBlock(p, Blocks.COARSE_DIRT.defaultBlockState(), 2);
            }
        }
        int[][] pos = {{-8, -8}, {8, -8}, {-8, 8}, {8, 8}};
        for (int i = 0; i < pos.length; i++) {
            house(l, cx + pos[i][0] + rnd.nextInt(3) - 1, cz + pos[i][1] + rnd.nextInt(3) - 1, rnd, i == 0);
        }
    }

    private static void house(ServerLevel l, int x, int z, RandomSource rnd, boolean withChest) {
        int gy = ground(l, x, z);
        for (int dx = -2; dx <= 2; dx++) {
            for (int dz = -2; dz <= 2; dz++) {
                set(l, x + dx, gy, z + dz, rnd.nextFloat() < 0.3f ? Blocks.MOSSY_COBBLESTONE.defaultBlockState() : Blocks.COBBLESTONE.defaultBlockState());
                for (int y = 1; y <= 4; y++) {
                    boolean corner = Math.abs(dx) == 2 && Math.abs(dz) == 2;
                    boolean wall = Math.abs(dx) == 2 || Math.abs(dz) == 2;
                    BlockState s = AIR;
                    if (y <= 3 && wall && rnd.nextFloat() > 0.2f + 0.12f * y) {
                        s = corner ? Blocks.SPRUCE_LOG.defaultBlockState() : Blocks.OAK_PLANKS.defaultBlockState();
                    }
                    if (y == 4 && rnd.nextFloat() < 0.3f) s = Blocks.OAK_PLANKS.defaultBlockState();
                    if (dx == 0 && dz == -2 && y <= 2) s = AIR;
                    set(l, x + dx, gy + y, z + dz, s);
                }
            }
        }
        if (withChest) chest(l, x + 1, gy + 1, z + 1, new ItemStack(ModItems.MEMORY_PAGE.get(), 3), new ItemStack(ModItems.SHARD.get(), 1));
    }

    // ------------------------------------------------------------ арена в Трещине
    public static void ensureArena(ServerLevel rift, ServerLevel ow) {
        State st = State.get(ow);
        if ((st.built & 16) != 0) return;
        for (int k = 0; k < 6; k++) {
            double a = 2 * Math.PI * k / 6;
            int x = (int) Math.round(Math.cos(a) * 11), z = (int) Math.round(Math.sin(a) * 11);
            for (int y = 4; y <= 8; y++) set(rift, x, y, z, Blocks.CRYING_OBSIDIAN.defaultBlockState());
            set(rift, x, 9, z, Blocks.END_ROD.defaultBlockState());
        }
        for (int dx = -4; dx <= 4; dx++) {
            for (int dz = -4; dz <= 4; dz++) {
                if (dx * dx + dz * dz <= 16) set(rift, dx, 3, dz, Blocks.POLISHED_BLACKSTONE.defaultBlockState());
            }
        }
        set(rift, 0, 3, 0, Blocks.SEA_LANTERN.defaultBlockState());
        st.built |= 16;
        st.setDirty();
    }
}
