package com.sanselo.mod.event;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.sanselo.mod.SanseloMod;
import com.sanselo.mod.data.PlayerData;
import com.sanselo.mod.data.PlayerRole;
import com.sanselo.mod.network.ModNetwork;
import com.sanselo.mod.story.MapGiver;
import com.sanselo.mod.story.StoryManager;
import com.sanselo.mod.worldgen.StructureGen;
import net.minecraftforge.items.ItemHandlerHelper;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = SanseloMod.MODID)
public class ModCommands {

    @SubscribeEvent
    public static void register(RegisterCommandsEvent e) {
        var disp = e.getDispatcher();

        disp.register(Commands.literal("role")
                .then(Commands.literal("get").executes(c -> {
                    ServerPlayer sp = c.getSource().getPlayerOrException();
                    sp.sendSystemMessage(Component.literal("Роль: " + PlayerData.get(sp).role));
                    return 1;
                }))
                .then(Commands.literal("choose").executes(c -> {
                    ModNetwork.openRoleScreen(c.getSource().getPlayerOrException());
                    return 1;
                }))
                .then(Commands.literal("set").requires(s -> s.hasPermission(2))
                        .then(Commands.literal("sanselo").executes(c -> {
                            StoryManager.startRole(c.getSource().getPlayerOrException(), PlayerRole.SANSELLO);
                            return 1;
                        }))
                        .then(Commands.literal("jdh").executes(c -> {
                            StoryManager.startRole(c.getSource().getPlayerOrException(), PlayerRole.JDH);
                            return 1;
                        }))));

        disp.register(Commands.literal("story")
                .executes(c -> {
                    StoryManager.showJournal(c.getSource().getPlayerOrException());
                    return 1;
                })
                .then(Commands.literal("map")
                        .then(Commands.literal("crater").executes(c -> { MapGiver.crater(c.getSource().getPlayerOrException()); return 1; }))
                        .then(Commands.literal("lab").executes(c -> { MapGiver.lab(c.getSource().getPlayerOrException()); return 1; }))
                        .then(Commands.literal("library").executes(c -> { MapGiver.library(c.getSource().getPlayerOrException()); return 1; })))
                .then(Commands.literal("advance").requires(s -> s.hasPermission(2)).executes(c -> {
                    ServerPlayer sp = c.getSource().getPlayerOrException();
                    PlayerData d = PlayerData.get(sp);
                    if (d.role != PlayerRole.NONE && d.chapter >= 1 && d.chapter < 14) {
                        StoryManager.enter(sp, d, d.chapter + 1);
                    }
                    return 1;
                })));

        disp.register(Commands.literal("storymap").executes(c -> {
            ServerPlayer sp = c.getSource().getPlayerOrException();
            ItemHandlerHelper.giveItemToPlayer(sp, StructureGen.makeMap(sp.getServer().overworld()));
            return 1;
        }));

        disp.register(Commands.literal("girlname")
                .then(Commands.argument("name", StringArgumentType.greedyString()).executes(c -> {
                    ServerPlayer sp = c.getSource().getPlayerOrException();
                    PlayerData d = PlayerData.get(sp);
                    String n = StringArgumentType.getString(c, "name").trim();
                    if (d.role == PlayerRole.NONE || d.chapter < 3 || d.chapter > 14) {
                        sp.sendSystemMessage(Component.literal("Девочка-клон появится в главе 3 и останется до главы 14."));
                        return 0;
                    }
                    if (n.isEmpty() || n.length() > 16) {
                        sp.sendSystemMessage(Component.literal("Имя должно быть от 1 до 16 символов."));
                        return 0;
                    }
                    d.girlName = n;
                    sp.sendSystemMessage(Component.literal("Девочку теперь зовут " + n + "."));
                    return 1;
                })));

        disp.register(Commands.literal("ending")
                .then(Commands.argument("n", IntegerArgumentType.integer(1, 4)).executes(c -> {
                    StoryManager.choose(c.getSource().getPlayerOrException(), IntegerArgumentType.getInteger(c, "n"));
                    return 1;
                })));
    }
}
