package com.sanselo.mod.client;

import com.sanselo.mod.entity.StoryNpcEntity;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.resources.ResourceLocation;

public class NpcRenderer extends HumanoidMobRenderer<StoryNpcEntity, StoryModel<StoryNpcEntity>> {
    private static final ResourceLocation JDH = new ResourceLocation("sanselomod", "textures/entity/jdh.png");
    private static final ResourceLocation SANSELO = new ResourceLocation("sanselomod", "textures/entity/sanselo.png");

    public NpcRenderer(EntityRendererProvider.Context ctx) {
        super(ctx, new StoryModel<>(ctx.bakeLayer(ModelLayers.PLAYER)), 0.5f);
    }

    @Override
    public ResourceLocation getTextureLocation(StoryNpcEntity e) {
        return e.variantId() == 0 ? JDH : SANSELO;
    }
}
