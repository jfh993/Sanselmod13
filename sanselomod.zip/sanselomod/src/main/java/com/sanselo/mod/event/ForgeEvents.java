package com.sanselo.mod.event;

import com.sanselo.mod.SanseloMod;
import com.sanselo.mod.data.PlayerData;
import com.sanselo.mod.data.PlayerDataProvider;
import com.sanselo.mod.data.PlayerRole;
import com.sanselo.mod.entity.SilentCloneEntity;
import com.sanselo.mod.fx.Fx;
import com.sanselo.mod.worldgen.StructureGen;
import net.minecraft.world.level.Level;
import com.sanselo.mod.registry.ModDimensions;
import com.sanselo.mod.network.ModNetwork;
import com.sanselo.mod.registry.ModItems;
import com.sanselo.mod.story.StoryManager;
import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.AttachCapabilitiesEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = SanseloMod.MODID)
public class ForgeEvents {

    @SubscribeEvent
    public static void attach(AttachCapabilitiesEvent<Entity> e) {
        if (e.getObject() instanceof Player) {
            e.addCapability(new ResourceLocation(SanseloMod.MODID, "data"), new PlayerDataProvider());
        }
    }

    @SubscribeEvent
    public static void clone(PlayerEvent.Clone e) {
        Player old = e.getOriginal();
        old.reviveCaps();
        old.getCapability(PlayerData.CAP).ifPresent(o ->
                e.getEntity().getCapability(PlayerData.CAP).ifPresent(n -> n.copyFrom(o)));
        old.invalidateCaps();
    }

    @SubscribeEvent
    public static void login(PlayerEvent.PlayerLoggedInEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer sp)) return;
        PlayerData d = PlayerData.get(sp);
        ModNetwork.sync(sp);
        if (d.role == PlayerRole.NONE) {
            ModNetwork.openRoleScreen(sp);
        } else {
            sp.sendSystemMessage(Component.literal("Журнал сюжета: /story").withStyle(ChatFormatting.GRAY));
        }
    }

    @SubscribeEvent
    public static void respawn(PlayerEvent.PlayerRespawnEvent e) {
        if (e.getEntity() instanceof ServerPlayer sp) ModNetwork.sync(sp);
    }

    @SubscribeEvent
    public static void dimension(PlayerEvent.PlayerChangedDimensionEvent e) {
        if (e.getEntity() instanceof ServerPlayer sp) ModNetwork.sync(sp);
    }

    @SubscribeEvent
    public static void pickup(PlayerEvent.ItemPickupEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer sp)) return;
        ItemStack stack = e.getStack();
        PlayerData d = PlayerData.get(sp);
        if (d.role == PlayerRole.NONE) return;
        if (stack.is(ModItems.SHARD.get())) {
            d.shards += stack.getCount();
            StoryManager.check(sp);
        } else if (stack.is(ModItems.MEMORY_PAGE.get())) {
            d.pages += stack.getCount();
            StoryManager.check(sp);
        }
    }

    @SubscribeEvent
    public static void death(LivingDeathEvent e) {
        // убийство клона
        if (e.getEntity() instanceof SilentCloneEntity && e.getSource().getEntity() instanceof ServerPlayer killer) {
            PlayerData d = PlayerData.get(killer);
            if (d.role != PlayerRole.NONE) {
                d.cloneKills++;
                StoryManager.check(killer);
            }
            return;
        }
        // Перенос сознания: Санселло возрождается в клоне
        if (e.getEntity() instanceof ServerPlayer sp) {
            PlayerData d = PlayerData.get(sp);
            long now = sp.level().getGameTime();
            if (d.role == PlayerRole.SANSELLO && d.chapter >= 2 && d.composure >= 30 && now >= d.transferReadyTick) {
                e.setCanceled(true);
                sp.setHealth(8f);
                sp.removeAllEffects();
                sp.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 100, 3));
                d.transferReadyTick = now + 6000;
                d.changeComposure(sp, -30);
                if (sp.level() instanceof ServerLevel sl) {
                    sl.sendParticles(ParticleTypes.REVERSE_PORTAL, sp.getX(), sp.getY() + 1, sp.getZ(), 80, 0.5, 1, 0.5, 0.3);
                    sl.broadcastEntityEvent(sp, (byte) 35);
                    Fx.spiral(sl, ParticleTypes.END_ROD, sp.getX(), sp.getY(), sp.getZ(), 1.0, 2.5, 50);
                }
                sp.sendSystemMessage(Component.literal("Сознание перенесено в клона. Следующий перенос будет доступен через 5 минут.")
                        .withStyle(ChatFormatting.LIGHT_PURPLE));
            }
        }
    }

    @SubscribeEvent
    public static void tick(TickEvent.PlayerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || !(e.player instanceof ServerPlayer sp) || sp.tickCount % 20 != 0) return;
        if (sp.tickCount % 40 == 0 && sp.level() instanceof ServerLevel ow0 && ow0.dimension() == Level.OVERWORLD) {
            StructureGen.tick(ow0, sp);
        }
        PlayerData d = PlayerData.get(sp);
        if (d.role == PlayerRole.NONE) return;
        if (sp.level() instanceof ServerLevel lvl) {
            if (lvl.dimension() == ModDimensions.RIFT) {
                lvl.sendParticles(ParticleTypes.REVERSE_PORTAL, sp.getX(), sp.getY() + 1, sp.getZ(), 30, 6, 2, 6, 0.05);
            }
            if (d.role == PlayerRole.SANSELLO && d.composure <= 40) {
                lvl.sendParticles(ParticleTypes.SCULK_SOUL, sp.getX(), sp.getY() + 2.1, sp.getZ(), 3, 0.3, 0.2, 0.3, 0.01);
            }
        }
        int held = countShards(sp);

        if (d.role == PlayerRole.SANSELLO) {
            if (sp.tickCount % 100 != 0) return;
            if (held >= 3 && d.chapter >= 3) {
                d.changeComposure(sp, -2); // Помутнение
            } else if (d.composure < 100) {
                d.changeComposure(sp, 1);
            }
        } else if (d.role == PlayerRole.JDH) {
            if (held >= 5 && d.chapter >= 3 && sp.tickCount % 600 == 0) {
                sp.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 100, 0));
            }
        }
    }

    private static int countShards(ServerPlayer sp) {
        int n = 0;
        for (ItemStack s : sp.getInventory().items) {
            if (s.is(ModItems.SHARD.get())) n += s.getCount();
        }
        return n;
    }
}
