package com.sanselo.mod.entity;

import com.sanselo.mod.data.PlayerData;
import com.sanselo.mod.data.PlayerRole;
import com.sanselo.mod.registry.ModItems;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

/** Безмолвный клон: бледный, молчаливый. Для Санселло нейтрален, пока тот не потеряет самообладание. */
public class SilentCloneEntity extends Monster {

    public SilentCloneEntity(EntityType<? extends Monster> type, Level level) {
        super(type, level);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 24.0)
                .add(Attributes.MOVEMENT_SPEED, 0.26)
                .add(Attributes.ATTACK_DAMAGE, 4.0)
                .add(Attributes.FOLLOW_RANGE, 24.0);
    }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.0, false));
        goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.8));
        goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 8.0f));
        goalSelector.addGoal(7, new RandomLookAroundGoal(this));
        targetSelector.addGoal(1, new HurtByTargetGoal(this));
        targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, 10, true, false, SilentCloneEntity::hostileTo));
    }

    public static boolean hostileTo(LivingEntity e) {
        if (!(e instanceof Player p)) return false;
        PlayerData d = PlayerData.get(p);
        return d.role != PlayerRole.SANSELLO || p.level().getGameTime() < d.lossUntil;
    }

    @Override
    protected void dropCustomDeathLoot(DamageSource source, int looting, boolean recentlyHit) {
        super.dropCustomDeathLoot(source, looting, recentlyHit);
        if (random.nextFloat() < 0.30f + 0.10f * looting) {
            spawnAtLocation(ModItems.SHARD.get());
        }
        if (random.nextFloat() < 0.25f + 0.05f * looting) {
            spawnAtLocation(ModItems.MEMORY_PAGE.get());
        }
    }

    @Override
    public void die(DamageSource source) {
        super.die(source);
        if (level() instanceof ServerLevel sl) {
            sl.sendParticles(ParticleTypes.ASH, getX(), getY() + 1, getZ(), 40, 0.4, 0.8, 0.4, 0.02);
            sl.sendParticles(ParticleTypes.SOUL, getX(), getY() + 1, getZ(), 8, 0.3, 0.6, 0.3, 0.03);
        }
    }

    @Override
    public void aiStep() {
        super.aiStep();
        if (level() instanceof ServerLevel sl && tickCount % 20 == 0) {
            sl.sendParticles(ParticleTypes.ASH, getX(), getY() + 1.6, getZ(), 2, 0.2, 0.4, 0.2, 0.01);
        }
    }

    @Override protected SoundEvent getAmbientSound() { return null; } // безмолвные
    @Override protected SoundEvent getHurtSound(DamageSource s) { return SoundEvents.PLAYER_HURT; }
    @Override protected SoundEvent getDeathSound() { return SoundEvents.PLAYER_DEATH; }
}
