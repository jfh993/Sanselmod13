package com.sanselo.mod.client;

import com.sanselo.mod.entity.Animated;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Mob;

/** Модель игрока (со вторым слоем скина) с собственными анимациями для jdh, Санселло и боссов. */
public class StoryModel<T extends Mob & Animated> extends PlayerModel<T> {
    public StoryModel(ModelPart root) {
        super(root, false);
    }

    @Override
    public void setupAnim(T e, float limbSwing, float limbSwingAmount, float age, float headYaw, float headPitch) {
        super.setupAnim(e, limbSwing, limbSwingAmount, age, headYaw, headPitch);
        int v = e.variantId(), ph = e.phaseId();
        float t = age;

        if (v == 0) { // jdh: театральные размашистые жесты
            rightArm.xRot += Mth.sin(t * 0.35f) * 0.9f - 0.3f;
            rightArm.zRot += 0.25f + Mth.sin(t * 0.5f) * 0.4f;
            leftArm.xRot += Mth.sin(t * 0.35f + 2.0f) * 0.9f - 0.3f;
            leftArm.zRot -= 0.25f + Mth.sin(t * 0.45f) * 0.4f;
            head.zRot += Mth.sin(t * 0.2f) * 0.12f;
        } else if (v == 1) { // Санселло: холодная неподвижность, голова опущена
            rightArm.xRot += -0.15f + Mth.sin(t * 0.08f) * 0.05f;
            leftArm.xRot += -0.15f + Mth.sin(t * 0.08f + 1.5f) * 0.05f;
            head.xRot += 0.18f;
            body.yRot += Mth.sin(t * 0.05f) * 0.08f;
        } else { // остальные: руки вперёд
            rightArm.xRot += -0.8f + Mth.sin(t * 0.1f) * 0.1f;
            leftArm.xRot += -0.8f + Mth.sin(t * 0.1f + 1f) * 0.1f;
        }

        if (ph == 2) { // заклинание: руки подняты
            rightArm.xRot = -2.6f + Mth.sin(t * 0.3f) * 0.08f;
            leftArm.xRot = -2.6f + Mth.sin(t * 0.3f + 1f) * 0.08f;
            rightArm.zRot = -0.2f;
            leftArm.zRot = 0.2f;
        } else if (ph >= 3) { // ярость: руки раскинуты и дрожат
            rightArm.xRot = 0f;
            leftArm.xRot = 0f;
            rightArm.zRot = 1.3f + Mth.sin(t * 0.9f) * 0.15f;
            leftArm.zRot = -1.3f - Mth.sin(t * 0.9f) * 0.15f;
            body.xRot = 0.15f;
        }

        // второй слой скина следует за основным
        leftSleeve.copyFrom(leftArm);
        rightSleeve.copyFrom(rightArm);
        jacket.copyFrom(body);
        hat.copyFrom(head);
    }
}
