package com.sanselo.mod.entity;

/** Для моделей: какой образ и какая фаза боя сейчас у сущности. */
public interface Animated {
    /** 0 = jdh, 1 = Санселло, 2 = Вея и прочие. */
    int variantId();

    /** 1 = обычная поза, 2 = заклинание, 3 = ярость. */
    int phaseId();
}
